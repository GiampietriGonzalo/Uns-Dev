Compilar asistente.c con el siguiente comando:

	:~$gcc -pthread -o asistente asistente.c
