#include <stdlib.h>
#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <math.h>
#include <unistd.h>

#define ESTUDIANTES 5
#define SILLAS 3

sem_t hayAlumnoEsperando;
sem_t sillas_disp;
sem_t alumno_atendido;
sem_t dormido;
sem_t llamada;


void *alumno(void *argv);
void *asis(void *argv);
void ayudar();

int i;

void main(){

	pthread_t hilos[ESTUDIANTES];
	pthread_t asistente;

	sem_init(&hayAlumnoEsperando, 0, 0);
	sem_init(&sillas_disp,0 ,SILLAS);
	sem_init(&alumno_atendido,0,0);
	sem_init(&llamada,0,0);
	sem_init(&dormido, 0, 1);

	
	for(i=0; i<ESTUDIANTES; i++){
		int *n=malloc(sizeof(int));
		*n=i;
		if(0!= pthread_create(&hilos[i], NULL, alumno,  n)){
			printf("Hubo un error en la creacion de hilos..\n");
			exit(1);
		}
			
	}
	
	sleep(1);

	if(0!= pthread_create(&asistente, NULL, asis, NULL)){
			printf("Hubo un error en la creacion de hilos..\n");
			exit(1);
	}
	
	for(i=0; i<ESTUDIANTES;i++){
		pthread_join(hilos[i], NULL);
	}
	pthread_join(asistente, NULL);

}


void *alumno(void *argv){

	int *a = (int*)argv;

	while(1){

		printf("\n<Alumno %i>: Ingreso a la oficina.\n",*a);

		if(sem_trywait(&sillas_disp)==0){	//Si hay sillas disponibles, alumno ocupa una silla
												
			printf("\n<Alumno %i>: Tomo asiento y espero.\n",*a);
			sleep(1);

			sem_post(&hayAlumnoEsperando);	
							
			if(sem_trywait(&dormido)==0)
				//Si es el primer alumno, despierta al asistente.											
				printf("\n<Alumno %i>: Desperté al asistente\n",*a);								
			

			//El alumno espera la llamada del asistente.
			sem_wait(&llamada);
			printf("\n<Alumno %i>: He sido llamado por el asistente para ser atendido\n",*a);
			
	
			sem_post(&sillas_disp);			//Se libera el asiento ocupado por el alumno llamado por el asistente.
			sem_wait(&alumno_atendido);		//Se espera la terminación de la asistencia.
		
			printf("\n<Alumno %i>: Ya terminé, me retiro de la oficina\n",*a);	

		}
		else								
			//No hay sillas disponibles, intenta mas tarde.
			printf("\n<Alumno %i>: No hay sillas disponibles. Volveré más tarde.\n",*a);								
		
		//Retiro aleatorio. A menor módulo, con más frecuencia vuelven los alumnos a la oficina, y menos probabilidades
		//de que el asistente duerma.	
		sleep(rand()%50); 
	}
	
}

void *asis(void *argv){

	while(1){

		//Espera a que haya un alumno esperando en la oficina.
		sem_wait(&hayAlumnoEsperando);
			
		sleep(1);	

		printf("\n<Asistente>: Llamo al siguiente alumno, si es que hay algún alumno esperando\n");	
	
		sem_post(&llamada);	

		sleep(1);

		ayudar();	

		if(sem_trywait(&hayAlumnoEsperando)==0)
			sem_post(&hayAlumnoEsperando);
		else{
			printf("\n<Asistente>:No hay alumnos.El asistente se va a dormir..\n");
			printf("\n<<<.....Asistente durmiendo.....>>>\n");
			sleep(1);
			sem_post(&dormido);
		}
	}
}

void ayudar(){

	printf("\n<Asistente>: Estoy ayudando a un alumno\n");
	sleep((rand()%3)+1);
	sem_post(&alumno_atendido);
	printf("\n<Asitente>: He terminado de atender al alumno\n");

}
