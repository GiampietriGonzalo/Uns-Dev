#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

//int rmdir(char *path);

int main(int argc, char *argv[]){

	if(argc==0)
		printf("\n[ERROR]: No ingreso los argumentos suficientes. \n");
	else{
		int resul;
		resul=rmdir(argv[0]);
	}
}

