#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>


/*
Recibe el nombre del archivo a crear y el modo
int mkdir (char *path, mode_t m);
*/

int main(int argc, char *argv[]){


	if(argc==0)
		printf("\n[ERROR]:Argumentos inválidos. \n");
	else{
		int resul;
		resul=mkdir(argv[0], 0777);
	}
	

	return 0;
}


