Para compilar los archivos .c, dar permisos al archivo 'compiladorMINI.sh' con el siguiente comando:

		:~$chmod +x compiladorMINI.sh
