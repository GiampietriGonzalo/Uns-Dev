#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>


void leerArchivo();


int main (int argc, char *argv[] ){

	
	if(argc==0)
		printf("\n[ERROR]:No ingreso los argumentos suficientes.\n");
	else
		leerArchivo(argv[0]);
	

	return 0;
}


void leerArchivo(char *direccion){

	int c;
	FILE *fd;
	fd=fopen(direccion, "rt");
	if(fd== NULL){
		printf("\n[ERROR]: Archivo inexistente. \n");
		exit(1);
	}

	else{
		while((c=fgetc(fd))!=EOF){
			if(c=='\n')
				printf("\n");
			else
				putchar(c);
						
		}
	}
	printf("\n");
	fclose(fd);
		
}
