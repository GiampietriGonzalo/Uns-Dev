#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

char comando[20];
char argumento[50];
int pid;

//Determina si el comando ingresado pertenece a nuestro conjunto de comandos posibles.
int comandoValido(char comando[]);

//Determina si el comando ingresado debe contemplar parámetros.
int comandoDeArgumento(char comando[]);

int main(){
	
	printf("\n<<<Bienvenido a la Minishell>>>\n");

	printf("\nComandos disponibles:\n\n");	

    printf("1)mkdir [directorio]\n");
    printf("2)rmdir [directorio]\n");
    printf("3)touch [archivo]\n");
    printf("5)ls\n");
    printf("6)cat   [archivo]\n");
    printf("7)man\n");
    printf("9)exit\n\n");

	printf("Para más información ejecutar el comando 'man'.\n");
	
	while(1){

		
		printf("\nuser@minishell:~$ ");

		fflush(stdout);

		scanf("%s", comando);

		if(comandoValido(comando)){

			if(comandoDeArgumento(comando))
				scanf("%s",argumento);

			if((strcmp(comando,"exit")==0)){
				exit(0);
			}
			else{

				pid=fork();
				switch(pid){

					case -1:{ 
						printf("Error.");
						exit(1);
					}
	
					case 0: {
						fflush(stdout);
						execl(comando, argumento);											
						exit(0);
					}

					/*Espera que termine el proceso hijo.*/
					default:
						wait(NULL);
				
				}
			}
		}
		else
			//El comando ingresado no es válido.
			printf("\n[ERROR]: El comando ingresdo no es válido\n");
	}

	return 0;
}

//Determina si el comando ingresado pertenece a nuestro conjunto de comandos posibles.
int comandoValido(char comando[]){

	int res=0;
	if((strcmp(comando, "exit")==0) || (strcmp(comando, "man")==0) || (strcmp(comando, "ls")==0) || (strcmp(comando, "mkdir")==0) || 		   (strcmp(comando, "rmdir")==0) || (strcmp(comando, "cat")==0) || (strcmp(comando, "touch")==0) || (strcmp(comando, "rmdir")==0))
			
		res=1;

	return res;
}

//Determina si el comando ingresado debe contemplar parámetros.
int comandoDeArgumento(char comando[]){

	int res=0;

	if(	(strcmp(comando, "exit")!=0) && (strcmp(comando, "man")!=0) && (strcmp(comando, "ls")!=0) )
		res=1;


	return res;
}

