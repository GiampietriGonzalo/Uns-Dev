#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>




int main(){

	int c;
	FILE *fd;
	fd=fopen("help.txt", "rt");

	if(fd== NULL){
		printf("\n[ERROR]: El archivo help.txt no se ha encontrado\n");
		exit(1);
	}
	else{
		
		printf("\n");

		while((c=fgetc(fd))!=EOF){
			if(c=='\n')
				printf("\n");
			else
				putchar(c);
						
		}
	}
	printf("\n");
	fclose(fd);
	

	return 0;
}
