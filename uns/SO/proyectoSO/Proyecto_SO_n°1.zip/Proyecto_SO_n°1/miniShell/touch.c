#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>


/*funcion touch*/


int main (int argc, char *argv[] ){

	if(argc==0){
		printf("No ingreso los argumentos suficientes.\n");
	}
	else{
		int c;
		FILE *fd;
		fd=fopen(argv[0], "w");

		printf("\n[EXITO]:Archivo actualizado. \n");
		fclose(fd);
	}
	
	return 0;
}
