#!/bin/bash
echo 'Compilando ....'

gcc miniShell.c -pthread -o  miniShell
gcc ls.c -o ls
gcc cat.c -o cat
gcc man.c -o man
gcc mkdir.c -o mkdir
gcc rmdir.c -o rmdir
gcc touch.c -o touch

echo 'Compilación finalizada ...'
