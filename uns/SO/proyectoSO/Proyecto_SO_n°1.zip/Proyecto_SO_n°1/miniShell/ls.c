#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>


/*int ls (char * options, char * file)*/


int main (int argc, char *argv[] ){

	DIR *dp;
	struct dirent *ep;
	dp=opendir("./");
	if(dp!=NULL){
		while(ep=readdir(dp))
			puts(ep->d_name);
		(void) closedir (dp);
	}
	else{
		perror("\n[ERROR]: No es posible listar el directorio\n");
	}
	
	return 0;
}
