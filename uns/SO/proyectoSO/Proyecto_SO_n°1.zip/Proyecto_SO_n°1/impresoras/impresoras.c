#include <stdlib.h>
#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <math.h>
#include <unistd.h>

#define USUARIOS 10


//SEMAFOROS
sem_t impresora1;
sem_t impresora2;
sem_t disponible;

//METODOS
void *usuario(void *argv);
int requerir();
void liberar(int u,int i);


void main(){

	int i;
	
	//UTIL PARA LOS JOIN
	pthread_t hilos[USUARIOS];

	//INICIZALIZACION DE SEMAFOROS
	sem_init(&impresora1, 1, 1);
	sem_init(&impresora2, 1, 1);
	sem_init(&disponible, 1, 2);


	for(i=0; i<USUARIOS; i++){

		int *n=malloc(sizeof(int));
		*n=i;

		if(0!= pthread_create(&hilos[i], NULL, usuario, n)){
			printf("Hubo un error en la creacion de hilos..\n");
			exit(1);
		}
			
	}

	for(i=0; i<USUARIOS;i++){
		pthread_join(hilos[i], NULL);
	}


}

void *usuario(void *argv){
	int *u=(int*) argv;
	int i;

	while(1){
		sleep(rand()%(3+1));
		printf("\n<Usuario %i>: Esperando...\n",*u);
		i=requerir();
		printf("\n<Usuario %i>: he obtenido y estoy usando la impresora %i\n",*u,i);
		sleep(rand()%(4+1));
		liberar(*u,i);
		sleep(1);
	}

}

int requerir(){

	int res;
	sem_wait(&disponible);
	if(sem_trywait(&impresora1)==0)
		res=1;
	else{
		sem_wait(&impresora2);
		res=2;
	}
	return res;
}

void liberar(int u,int i){
	
	if(i==1)
		sem_post(&impresora1);
	else
		sem_post(&impresora2);

	printf("\n<Usuario %i>: liberé la impresora %i\n",u,i);
	sem_post(&disponible);
}
