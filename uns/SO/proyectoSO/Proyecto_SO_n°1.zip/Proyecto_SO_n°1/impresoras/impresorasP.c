#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>
#include <semaphore.h>

#define cantImpresoras 2
#define cantUsuarios 5

typedef struct user{
	sem_t miSemaforo;
	sem_t utilizando;
	int prioridad;	

}*usuario;


//SEMAFOROS
sem_t disponible;
pthread_mutex_t mutexIMP;

//Arreglo que representa a los usuarios esperando
usuario usuariosEsperando[cantUsuarios];

//METODOS
usuario getMayorPrioridad();
void *encender(void *arg);
void *requerir(void *arg);
void liberar(int nimp,usuario u);


void main(){

	pthread_t hImpresoras[cantImpresoras];
	pthread_t usuarios[cantUsuarios];
	usuario usuarioAux;
	
	//INICIALIZACION DE LOS SEMAFOROS
	sem_init(&disponible,0,2);
	pthread_mutex_init(&mutexIMP, NULL);	

	//INICIALIZACION DE LOS HILOS
	
	for(int i=0;i<cantUsuarios;i++){
	
		usuarioAux=malloc(sizeof(struct user));
		sem_init(&(usuarioAux->miSemaforo),0,0);
		sem_init(&(usuarioAux->utilizando),0,0);		
		usuarioAux->prioridad=i;			

		if(pthread_create(&(usuarios[i]),NULL,requerir, usuarioAux)!=0){
			printf("\nERROR al crear un hilo para el usuario n°%i \n",i+1);
			exit(1);		
		}
	}

	sleep(1);

	for(int j=0;j<cantImpresoras;j++){
	
		int *id=malloc(sizeof(int));
		*id=j+1;

		if(pthread_create(&(hImpresoras[j]),NULL,encender, id)!=0){
			printf("\nERROR al crear un hilo para la impresora n°%i \n",j+1);
			exit(1);		
		}
	}


	//JOINS
	for(int j=0;j<cantUsuarios;j++)	
		if(pthread_join((usuarios[j]),0)!=0){
			printf("\nERROR en join para el usuario n°%i \n",j);
			exit(1);
		}
	
 	for(int j=0;j<cantImpresoras;j++)	
		if(pthread_join((hImpresoras[j]),0)!=0){
			printf("\nERROR en join para la impresora n°%i \n",j);
			exit(1);
		}


}

void *requerir(void *arg){

	while(1){

		usuario esteUsuario=(usuario) arg;
		sem_post(&(esteUsuario->utilizando));
		
		pthread_mutex_lock(&mutexIMP);
		usuariosEsperando[esteUsuario->prioridad]=esteUsuario;		
		pthread_mutex_unlock(&mutexIMP);

		printf("\n<Usuario n°%i>: Esperando...\n",esteUsuario->prioridad);
	
		sleep(1);	

		sem_wait(&(esteUsuario->miSemaforo));
		sem_wait(&(esteUsuario->utilizando));;

		//Requerido para evitar la inanición de los usuarios con prioridades bajas.
		//Al realizar módulo con un menor número, aumentan las probabilidades de inanición.
		usleep(rand()%10000000);
	}
		
	pthread_exit(0);

}

void *encender(void *arg){
		
	int *id=(int*) arg;
	usuario mayorU=NULL;

	while(1){
	
		sem_wait(&disponible);

		//Busca al siguiente usuario con mayor prioridad - BLOQUEA EL MUTEX
		pthread_mutex_lock(&mutexIMP);
		mayorU=getMayorPrioridad();
		pthread_mutex_unlock(&mutexIMP); //DESBLOQUEA EL MUTEX
	

		if(mayorU!=NULL){

			sem_wait(&(mayorU->utilizando));

			sem_post(&(mayorU->miSemaforo));

			printf("\n<---Se ha quitado de la espera al usuario con prioridad n°%i--->\n",mayorU->prioridad);
			sleep(1);
			printf("\n<Impresora n°%i>: Estoy siendo utilizado por el usuario n°%i \n",*id,mayorU->prioridad);	

			usleep(rand()%100000);
			liberar(*id,mayorU);	
		
		}

		sem_post(&disponible);		

	}

	

	pthread_exit(0);

}

void liberar(int nimp,usuario u){

	sleep(1);
	sem_post(&(u->utilizando));
	
	printf("\n<Impresora n°%i>: He sido liberada por el usuario n°%i\n",nimp,u->prioridad);
}

/*
A menor posición, mayor prioridad;
*/
usuario getMayorPrioridad(){

	usuario mayorU=NULL;
	int mayorP=100;
	int i=0;
	int idMayor=0;
	
	while(i<cantUsuarios){

		if((usuariosEsperando[i]!=NULL) && mayorP>(usuariosEsperando[i]->prioridad)){

			mayorP=usuariosEsperando[i]->prioridad;
			mayorU=usuariosEsperando[i];
			idMayor=i;				

		}
		
		i++;
	}

	if(mayorU!=NULL){
		
		usuariosEsperando[idMayor]=NULL;
	}

	return mayorU;
}
