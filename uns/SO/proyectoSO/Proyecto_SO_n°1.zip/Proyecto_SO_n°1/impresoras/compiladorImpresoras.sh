#!/bin/bash
echo 'Compilando ....'

gcc -pthread -o imp impresoras.c
gcc -pthread -o impp impresorasP.c

echo 'Compilación finalizada ...'
