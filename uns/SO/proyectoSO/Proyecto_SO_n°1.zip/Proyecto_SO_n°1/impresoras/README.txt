Para compilar los archivos .c, dar permisos al archivo 'compiladorImpresoras.sh' con el siguiente comando:

		:~$chmod +x compiladorImpresoras.sh
