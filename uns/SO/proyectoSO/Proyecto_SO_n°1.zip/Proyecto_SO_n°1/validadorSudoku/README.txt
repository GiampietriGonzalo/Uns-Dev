Para compilar los archivos .c, dar permisos al archivo 'compiladorSudoku.sh' con el siguiente comando:

		:~$chmod +x compiladorSudoku.sh
