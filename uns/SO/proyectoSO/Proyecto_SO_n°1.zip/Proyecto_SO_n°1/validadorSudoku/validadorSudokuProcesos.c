#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

void cargarGrilla();
void verificar (int arreglo [], char *nombreArch);
int buscar (int nro, int arreglo[]);
void creoSubgrilla(int p);
void escribirResultado(char *archivo, int valor);
int leerResul(char *archivo);
void eliminarArchivos(char *archivos[]);

/*
Abre el archivo sudoku.txt, carga los datos en una grilla
y crea los 27 procesos para su verificacion.
*/

char *archivos [27]= {"archivo0.txt", "archivo1.txt", "archivo2.txt", "archivo3.txt", "archivo4.txt", "archivo5.txt", "archivo6.txt",
							"archivo7.txt", "archivo8.txt", "archivo9.txt", "archivo10.txt", "archivo11.txt", "archivo12.txt", 
							"archivo13.txt", "archivo14.txt", "archivo15.txt", "archivo16.txt", "archivo17.txt", "archivo18.txt",
							"archivo19.txt", "archivo20.txt", "archivo21.txt", "archivo22.txt", "archivo23.txt", "archivo24.txt",
							"archivo25.txt", "archivo26.txt",
						};

int arreglo[9];	
int grilla [9][9];
int subgrilla[3][3];

int main (){


	int f, c, g, pid, i, p;
	cargarGrilla();
	int resultado=1;
	
	/*
	Creo 9 procesos para verificar las filas, donde cada proceso crea un arreglo de
	9 elementos.
	*/
	for(f=0; f<9; f++){
		pid=fork();
		if(pid==-1)
			exit(1);
		else{
			if(pid==0){

				for(i=0; i<9; i++){
					arreglo[i]=grilla[f][i];
				}
				verificar(arreglo, archivos[f]);
				
			}
		}
	}

	/*Creo 9 procesos para verificar las columnas, donde cada proceso crea un arreglo de 9 elementos. */
	for(c=0; c<9; c++){
		pid=fork();
		if(pid==-1)
			exit(1);
		else{
			if(pid==0){
				for(i=0; i<9; i++){
					arreglo[i]=grilla[i][c];
				}
				verificar(arreglo, archivos[c+9]);
			}
		}
	}

	
	/*Creo 9 procesos para verificar las subgrillas, donde cada proceso crea un arreglo de 9 elementos. */
	for(g=0; g<9; g++){
		pid=fork();
		if(pid==-1)
			exit(1);
		else{
			if(pid==0){
				creoSubgrilla(g);
				verificar(arreglo, archivos[g+18]);
			}
		}
	}

	/*El proceso padre espera a que terminen los 27 procesos hijos.*/
	for(p=0; p<27;p++){
		wait(NULL);
	}

	
	/*
	Abro los 27 archivos para verificar si el sudoku es valido.
	*/
	
	p=0;

	while(resultado==1 && p<27){

		if(leerResul(archivos[p])==0){
			printf("\n[ERROR]: La jugada NO es válida.\n\n");
			resultado=0;
		}
		p++;
	}

	if(resultado==1)
		printf("\n[EXITO]: La jugada es válida\n\n");
	

	eliminarArchivos(archivos);

	return 0;
}



void cargarGrilla(){

	FILE *fd;
	char direccion []={"sudoku.txt"};
	fd=fopen(direccion, "rt");
	int c;
	int f=0;
	int col=0;
	
	if(fd== NULL){
		printf("\n[ERROR]: Archivo sudoku.txt inexistente\n\n");
		exit(1);
	}

	else{
		while((c=fgetc(fd))!=EOF){

			if(c=='\n'){
				f++;
				col=0;
			}				
			else{
				if(c!=','){
					grilla[f][col]=c-'0';
					col++;
				}			
			}
		}
	}

	fclose(fd);
	printf("\n");
	printf("Jugada:\n");
	printf("\n");

	for(f=0; f<9; f++){
		for(col=0; col<9; col++){
			printf(" %i", grilla[f][col]);
		}
		printf("\n");	
	}
	
}

void verificar (int arreglo[], char *nombreArch){

	int nro=1;
	int seVerifica=1;

	while(seVerifica==1 & nro<10){

		int resp;
		resp=buscar(nro, arreglo);
			if(resp==1)
				nro++;
			else
				seVerifica=0;
	}

	escribirResultado(nombreArch, seVerifica);
	exit(0);
	
}


int buscar (int nro, int arreglo[]){

	int aux=0;
	int j;

	for(j=0; j<9; j++){
		if(arreglo[j]==nro)
			aux=1;
	}

	return aux;
}

void escribirResultado(char *archivo, int valor){
	FILE *file;
	file=fopen(archivo, "w");
	fprintf(file, "%i", valor);
	fclose(file);

}

void creoSubgrilla(int p){
	int iniF=0;
	int iniC=0;
	int f,c;
	int r=0;

	switch(p){

		case 0:
			iniF=0;
			iniC=0;
		case 1:
			iniF=0;
			iniC=3;
		
		case 2:
			iniF=0;
			iniC=6;
			
		case 3:
			iniF=3;
			iniC=0;
			
		case 4:
			iniF=3;
			iniC=3;
			
		case 5:
			iniF=3;
			iniC=6;
			
		case 6:
			iniF=6;
			iniC=0;
			
		case 7:
			iniF=6;
			iniC=3;
			
		case 8:
			iniF=6;
			iniC=6;
			
	}

	
	for(f=iniF; f<iniF+3; f++){
		for(c=iniC; c<iniC+3; c++){
			arreglo[r]=grilla[f][c];
			r++;
		}
	}
}


int leerResul(char *archivo){

	int c;
	int res=1;
	FILE *file;
	file=fopen(archivo, "r");
	

	if(file==NULL){
		printf("[ERROR]: no se pudo leer el archivo para verificar el resultado");
		exit(1);	
	}
	else{
		c=fgetc(file);
		if(c==48)
			res=0;	
	}	
	
	fclose(file);
	
	return res;
}


/*
Se eliminan los archivos temporales creados.
*/
void eliminarArchivos(char *archivos[]){

	int i=0;
	while(i<27){
		if(remove(archivos[i])!=0){
			printf("\n[ERROR]: No se ha podido eliminar el archivo n°%i\n",i);
			exit(1);		
		}
		i++;	
	}

}
