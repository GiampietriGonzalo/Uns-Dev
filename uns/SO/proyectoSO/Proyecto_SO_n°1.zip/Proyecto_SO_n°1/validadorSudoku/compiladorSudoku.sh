#!/bin/bash
echo 'Compilando ....'

gcc -pthread -o vh validadorSudokuHilos.c
gcc -o vp validadorSudokuProcesos.c

echo 'Compilación finalizada ...'
