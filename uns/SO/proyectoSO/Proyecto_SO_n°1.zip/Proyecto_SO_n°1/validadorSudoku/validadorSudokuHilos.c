#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/stat.h>
#include <fcntl.h>


struct parametro{
	int i;
};

void cargarGrilla();
void *verificarFila (void *argv);
void *verificarColumna (void *argv);
void *verificarSubgrilla(void *argv);
int buscar (int nro, int arreglo[]);

pthread_t hilosFil[9];
pthread_t hilosCol[9];
pthread_t hilosSub[9];

int grilla [9][9];
int respuesta[3][9];

int main(){
	int f,c,s,res,j, h;
	int v;
	cargarGrilla();

	/*Creacion de 9 hilos para verificar las filas.*/
	for(f=0; f<9; f++){
		int *n=malloc(sizeof(int));
		*n=f;
		if(0!= pthread_create(&hilosFil[f], NULL, verificarFila,n))
			return -1;
	}

	/*Creacion de los 9 hilos para verificar las columnas.*/
	for(c=0; c<9; c++){
		int *n=malloc(sizeof(int));
		*n=c;
		if(0!= pthread_create(&hilosCol[c], NULL, verificarColumna, n))
			return -1;
	}

	/*Creacion de los 9 hilos para verificar las subgrillas.*/
	for(s=0; s<9; s++){
		int *n=malloc(sizeof(int));
		*n=s;
		if(0!= pthread_create(&hilosSub[s], NULL, verificarSubgrilla, n))
			return -1;	
	}		

	/*El proceso padre espera a que los 27 hilos terminen.*/
	for(j=0; j<9; j++){
		pthread_join(hilosFil[j], NULL);	
		pthread_join(hilosCol[j], NULL);
		pthread_join(hilosSub[j], NULL);
	}
	
	/*Recorre la grilla 'respuesta'. Si todos los elementos son
	igual a 1 la grilla es valida. Caso contrario, la jugada de 
	sudoku es invalida.*/
	for(h=0; h<3; h++){
		for(j=0;j<9;j++){
			if(respuesta[h][j]==0){
				printf("\n[ERROR]: La jugada NO es válida.\n\n");
				exit(1);
			}
			
		}
	}
	printf("\n[EXITO]: La jugada es válida.\n\n");

	return 0;
}


/*
Carga los datos del archivo "sudoku.txt" en una grilla y la muestra
por consola.
*/
void cargarGrilla(){

	FILE *fd;
	char direccion []="sudoku.txt";
	fd=fopen(direccion, "rt");

	int c;
	int f=0;
	int col=0;
	if(fd==NULL){
		printf("\n[ERROR]: archivo sudoku.txt inexistente\n\n");
		exit(1);

	}

	else{
		while((c=fgetc(fd))!=EOF){
			if(c=='\n'){
				f++;
				col=0;
			}
				
			else{
				if(c!=','){
					grilla[f][col]=c-'0';
					col++;
				}	
				
			}
		}

	}
	fclose(fd);
	printf("\n");
	printf("Jugada: \n");
	printf("\n");
	

	for(f=0; f<9; f++){
		for(col=0; col<9; col++){
			printf(" %i", grilla[f][col]);
		}
		printf("\n");	
	}
	
}

/*
Recibe como parametro el numero del hilo que ejecuta la funcion.
Crea una arreglo con los 9 elementos de una fila y verifica que contenga 
los numeros del 1 al 9.
Almacena 1 en la grilla 'respuesta' si el arreglo es valido.
0 en caso contrario.
*/
void *verificarFila (void *argv){
	int j;
	int arreglo[9];
	int p = *((int*) argv);
	for(j=0; j<9; j++){
		arreglo[j]=grilla[p][j];
	}

	int nro=1;
	int seVerifica=1;

	while(seVerifica==1 & nro<10){
		int resp;
		resp=buscar(nro, arreglo);
			if(resp==1)
				nro++;
			else
				seVerifica=0;
	}

	respuesta[0][p]=seVerifica;

}

/*
Recibe como parametro el numero del hilo que ejecuta la funcion.
Crea una arreglo con los 9 elementos de una columna y verifica que contenga 
los numeros del 1 al 9.
Almacena 1 en la grilla 'respuesta' si el arreglo es valido.
0 en caso contrario.
*/
void *verificarColumna (void *argv){

	int j;
	int arreglo[9];
	int p = *((int*) argv);
	for(j=0; j<9; j++){
		arreglo[j]=grilla[j][p];
	}
	int nro=1;
	int seVerifica=1;

	while(seVerifica==1 & nro<10){
		int resp;
		resp=buscar(nro, arreglo);
			if(resp==1)
				nro++;
			else
				seVerifica=0;
	}

	respuesta[1][p]=seVerifica;
}

/*
Recibe como parametro el numero del hilo que ejecuta la funcion.
Crea una arreglo con los 9 elementos de una subgrilla y verifica que contenga 
los numeros del 1 al 9.
Almacena 1 en la grilla 'respuesta' si el arreglo es valido.
0 en caso contrario.
*/
void *verificarSubgrilla(void *argv){
	int arreglo[9];
	int p = *((int*) argv);
	int iniF=0;
	int iniC=0;

	switch(p){

		case 0:
			iniF=0;
			iniC=0;
			break;
		case 1:
			iniF=0;
			iniC=3;
			break;
		case 2:
			iniF=0;
			iniC=6;
			break;
		case 3:
			iniF=3;
			iniC=0;
			break;
		case 4:
			iniF=3;
			iniC=3;
			break;
		case 5:
			iniF=3;
			iniC=6;
			break;
		case 6:
			iniF=6;
			iniC=0;
			break;
		case 7:
			iniF=6;
			iniC=3;
			break;
		case 8:
			iniF=6;
			iniC=6;
			break;
	}

	int pos=0;
	int f,c;
	for(f=iniF; f<iniF+3; f++){
		for(c=iniC; c<iniC+3; c++){
			arreglo[pos]=grilla[f][c];
			pos++;
		}
	}
	int nro=1;
	int seVerifica=1;

	while(seVerifica==1 & nro<10){
		int resp;
		resp=buscar(nro, arreglo);
			if(resp==1)
				nro++;
			else
				seVerifica=0;
	}
	respuesta[2][p]=seVerifica;
}

/*
Recorre un arreglo verificando que esten los numeros del 1 al 9.
*/
int buscar (int nro, int arreglo[]){

	int aux=0;
	int j;

	for(j=0; j<9; j++){
		if(arreglo[j]==nro)
			aux=1;
	}

	return aux;
}
