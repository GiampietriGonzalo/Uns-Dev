<?php
require_once('data_access.php');

/**
 * Recuperamos el criterio de la busqueda. 
 * Se obtiene por GET, en el índice 'term'
 */
$criterio = strtolower($_GET["term"]);

if ($criterio) {
	// Si recuperamos un criterio de búsqueda, filtramos en los datos

	/**
	 * Creamos un objeto data_access, que encapsula el acceso a datos
	 */
	$da = new data_access();

	/**
	 * Filtramos los datos
	 */
	$datos = $da->filtrar($criterio);

	/**
	 * Construimos un objeto JSON con los resultados, donde cada elemento 
	 * debe tener la forma:
	 * { label : "lo que quieras que aparezca escrito", value: { datos } }
	 */
	echo '[';
	$contador = 0;
	foreach ($datos as $clave => $valor) 
	{
		if ($contador++ > 0) {
			// agregamos esta linea porque cada elemento debe estar separado por una coma
			print ", "; 
		}
		$nombre = $valor['nombre'];
		$codigo_iso = $valor['codigo_iso'];
		print "{ \"label\" : \"$nombre\", \"value\" : {  \"nombre\" : \"$nombre\", \"codigo_iso\" : \"$codigo_iso\" } }";
	} 
	echo ']';
}
?>