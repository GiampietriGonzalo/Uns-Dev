<?php
//Conectarnos a la base de datos
require_once('connection.php');

//¿Están controlador y accion indicados?
if (isset($_GET['controller']) && isset($_GET['action'])) {
    $controller = $_GET['controller'];
    $action     = $_GET['action'];
} else {
    $controller = 'pages';
    $action     = 'home';
}

require_once('views/layout.php');
 ?>
