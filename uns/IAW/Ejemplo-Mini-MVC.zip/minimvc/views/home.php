<h2>Viva el Desarrollo Web</h2>
<p>
  <?php echo $saludo; ?>
</p>
