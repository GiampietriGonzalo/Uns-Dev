<DOCTYPE html>
<html>
  <head>
  </head>
  <body>
    <h1>Mini-mini-MVC</h1>
    <?php require_once('routes.php'); ?>

  <body>
<html>
