
<h3>Goleadores de los mundiales</h3>

<ol>
<?php foreach ($jugadores as $j): ?>
  <li><?php echo $j; ?>

<?php endforeach; ?>
</ol>
