<?php
class Goleadores {

  public static function todos() {
     $list = [];
     $db = Db::getInstance();
     $req = $db->query('SELECT * FROM players');

     // Lista de jugadores y goles
     foreach($req->fetchAll() as $jugador) {
       $list[] = $jugador['nombre']." con ".$jugador['goles'];
     }

     return $list;
   }

}



 ?>
