<?php
  class PagesController {

    public function home() {
      $saludo = "Hola Mundo!";
      require_once('views/home.php');
    }

    public function goleadores(){
        require_once('models/goleadores.php');
        $jugadores = Goleadores::todos();
        require_once('views/vistagoles.php');
    }

  }
?>
