<?php
  function call($controller, $action) {
    // buscamos el archivo php del controlador
    require_once('controllers/' . $controller . '_controller.php');

    // creamos una nueva instancia del controlador
    switch($controller) {
      case 'pages':
        $controller = new PagesController();
      break;
    }

    // invocar la accion
    $controller->{ $action }();
  }

  //Invocar al controlador y accion deseada
  call($controller,$action);

?>
