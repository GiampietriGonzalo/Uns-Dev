public class InvalidMarkerException extends Exception {

}
