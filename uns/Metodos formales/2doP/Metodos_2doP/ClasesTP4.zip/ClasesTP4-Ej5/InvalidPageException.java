public class InvalidPageException extends Exception{

}
