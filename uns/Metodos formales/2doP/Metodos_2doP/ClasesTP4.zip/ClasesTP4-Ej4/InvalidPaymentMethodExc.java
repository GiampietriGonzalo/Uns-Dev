public class InvalidPaymentMethodExc extends Exception{

}
