public class ExcepcionCantSaboresSuperada extends Exception {

}
