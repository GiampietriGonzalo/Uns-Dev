public class ExcepcionEnvasePrincipalInvalido extends Exception {

}
