public class ExcepcionEstanteriaVacia extends Exception {

}
