public class ExcepcionCambioEstadoTributario extends Exception {

}
