
public class Persona {

  private /*@ spec_public @*/ boolean femenino;
  private /*@ spec_public @*/ boolean masculino;
  /*@ public invariant (femenino!=masculino); @*/

  private /*@ spec_public @*/ int edad;
  /*@ public invariant edad>=0; @*/
  
  private /*@ spec_public @*/ boolean casada;
  /*@ public invariant (casada ==> (edad >= 18)); @*/

  private /*@ spec_public @*/ boolean contribuyente;
  /*@ public invariant( (femenino && (edad>=18 && edad<=60)) ==> contribuyente); @*/
  /*@ public invariant( (masculino && (edad>=18 && edad<=65)) ==> contribuyente); @*/

  /*@ public invariant ((contribuyente && masculino) ==> (edad>=18 && edad<=65)); @*/
  /*@ public invariant ((contribuyente && femenino) ==> (edad>=18 && edad<=60)); @*/	

  private /*@ spec_public @*/ int salario;
  /*@ public invariant (contribuyente ==> (salario >= SALARIO_MINIMO_VITAL_MOVIL)); @*/
  /*@ public invariant (!contribuyente ==> salario == 0); @*/

  private /*@ spec_public @*/ static final int SALARIO_MINIMO_VITAL_MOVIL = 10000;

  private /*@ spec_public @*/ int montoTributario;
  /*@ public invariant (contribuyente ==> (montoTributario > 0)); @*/
  /*@ public invariant (!contribuyente ==> (montoTributario == 0)); @*/


  private /*@ spec_public @*/ static final int MINIMO_NO_IMPONIBLE_BASE_SOLTERO = 15000;
  private /*@ spec_public @*/ static final int MINIMO_NO_IMPONIBLE_BASE_CASADO = 25000;


  

  public Persona (boolean f, boolean m, int e, boolean c, int s) {
    femenino = f;
    masculino = m;
    edad = e;
    casada = c;
    establecerSalario(s);
    montoTributario = obtenerMontoTributario();
    //< ESTA PROHIBIDO MODIFICAR EL CONSTRUCTOR >
  }


  private int obtenerMontoTributario(){
    if (contribuyente)
      if (casada)
        if (salario > MINIMO_NO_IMPONIBLE_BASE_CASADO)
          return salario - MINIMO_NO_IMPONIBLE_BASE_CASADO;
        else return 0;
      else  if (salario > MINIMO_NO_IMPONIBLE_BASE_SOLTERO)
              return salario - MINIMO_NO_IMPONIBLE_BASE_SOLTERO;
            else return 0;
    else return 0;
    //< ESTA PROHIBIDO MODIFICAR LA IMPLEMENTACION DE ESTE METODO >
  }


  /*@ public normal_behavior
    @ requires contribuyente;
	@ requires s >= SALARIO_MINIMO_VITAL_MOVIL;
    @ ensures salario == s;
	@ ensures salario >= SALARIO_MINIMO_VITAL_MOVIL;
	@ ensures montoTributario >0;
    @ assignable salario, montoTributario;
    @
    @ also
    @
    @ public normal_behavior
    @ requires !contribuyente;
    @ ensures salario == 0;
	@ ensures montoTributario == 0;
    @ assignable salario, montoTributario;
    @*/
  public void establecerSalario(int s){
    if (contribuyente)
      salario = s;
    else salario = 0;
    montoTributario = obtenerMontoTributario();
    //< ESTA PROHIBIDO MODIFICAR LA IMPLEMENTACION DE ESTE METODO >
  }



  /*@ public normal_behavior
    @ requires true;
    @ ensures edad == \old(edad) + 1;
    @*/
  public void actualizarEdad() throws ExcepcionCambioEstadoTributario{
    edad++;
    //< SE PERMITE MODIFICAR LA IMPLEMENTACION DE ESTE METODO >
  }

}
