public class ExcepcionFueraLimites extends Exception {

}
