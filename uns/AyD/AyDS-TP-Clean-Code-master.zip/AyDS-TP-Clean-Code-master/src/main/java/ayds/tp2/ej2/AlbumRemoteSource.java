package ayds.tp2.ej2;

public interface AlbumRemoteSource {

	Album getRemoteAlbum(int id);

}
