package ayds.tp2.ej1;

import java.net.URI;

public interface ServiceProvider {

  String resolveCall(URI uri);

}
