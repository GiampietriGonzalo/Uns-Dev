package ayds.tp2.ej2;

public interface AlbumLocalSource {

	Album getAlbum(int id);

	void saveAlbum(Album a);

}
